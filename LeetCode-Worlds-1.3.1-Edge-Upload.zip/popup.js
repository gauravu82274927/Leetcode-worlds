 'use strict';
const form = document.querySelector('#themes');
const options = document.querySelector('#options');
const customOptions = document.querySelector('#custom-options');
const status = document.querySelector('#status');
let current;
let queue = Promise.resolve();
function render() {
  document.querySelector(`input[name="theme"][value="${current.theme}"]`).checked = true;
  for (const key of ['enabled','motion','focus']) document.getElementById(key).checked = current[key];
  for (const key of ['accent','surface']) document.getElementById(key).value = current[key];
  const preview = document.getElementById('custom-preview');
  preview.style.backgroundImage = current.customImage ? `url("${current.customImage}")` : 'none';
  preview.style.backgroundColor = current.surface;
  preview.style.borderBottom = `3px solid ${current.accent}`;
}
function save(patch) {
  const next = LCW.normalize({...current,...patch});
  status.textContent = 'Saving…';
  queue = queue.then(async () => {
    await chrome.storage.local.set({worlds:next});
    current = next; render();
    status.textContent = 'Saved · applies across LeetCode';
  }).catch(() => { render(); status.textContent = 'Save failed. Your previous saved preferences are retained. Try a smaller image.'; });
  return queue;
}
chrome.storage.local.get('worlds').then(data => {
  current = LCW.normalize(data.worlds); render();
  form.disabled = options.disabled = customOptions.disabled = false;
  status.textContent = 'Ready · preferences saved on this device';
}).catch(() => { status.textContent = 'Could not load settings. Reopen the extension to retry.'; });
document.addEventListener('change', async event => {
  const input = event.target;
  if (!(input instanceof HTMLInputElement) || !current) return;
  await queue;
  if (input.id === 'upload') {
    const file = input.files[0]; if (!file) return;
    if (!['image/png','image/jpeg','image/webp'].includes(file.type) || file.size > 10*1024*1024) {
      status.textContent = 'Choose a PNG, JPEG or WebP image under 10 MB.'; input.value = ''; return;
    }
    status.textContent = 'Preparing image…';
    try {
      const bitmap = await createImageBitmap(file);
      const ratio = Math.min(1,1600/Math.max(bitmap.width,bitmap.height));
      const canvas = document.createElement('canvas');
      canvas.width = Math.max(1,Math.round(bitmap.width*ratio)); canvas.height = Math.max(1,Math.round(bitmap.height*ratio));
      const ctx = canvas.getContext('2d'); ctx.fillStyle = current.surface; ctx.fillRect(0,0,canvas.width,canvas.height);
      ctx.drawImage(bitmap,0,0,canvas.width,canvas.height); bitmap.close();
      const image = canvas.toDataURL('image/jpeg',.8);
      if (image.length > 2000000) throw new Error('Image too large');
      await save({customImage:image,theme:'custom'});
    } catch { status.textContent = 'Could not prepare that image. Try a smaller PNG or JPEG.'; }
    input.value = ''; return;
  }
  if (input.name === 'theme') {
    if (input.value === 'custom' && !current.customImage) {render(); status.textContent = 'Upload an image first to use your background.'; return;}
    await save({theme:input.value});
  } else if (['accent','surface'].includes(input.id)) {
    await save({[input.id]:input.value, ...(current.customImage ? {theme:'custom'} : {})});
  } else if (['enabled','motion','focus'].includes(input.id)) await save({[input.id]:input.checked});
});
document.getElementById('reset-custom').addEventListener('click', async () => {
  await queue;
  await save({customImage:'',accent:'#d77a9d',surface:'#18181c',theme:current.theme === 'custom' ? 'sakura' : current.theme});
});
