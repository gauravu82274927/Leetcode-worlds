(() => {
  'use strict';
  let settings = LCW.normalize();
  let loaded = false;
  let revision = 0;
  let lastPath = '';
  let scene;
  const root = document.documentElement;
  function apply() {
    const active = loaded && settings.enabled;
    for (const name of ['world', 'motion', 'focus']) root.removeAttribute(`data-lcw-${name}`);
    if (!active) { root.style.removeProperty('--lcw-accent'); root.style.removeProperty('--lcw-surface'); scene?.remove(); scene = undefined; return; }
    root.setAttribute('data-lcw-world', settings.theme);
    if (settings.motion && !settings.focus) root.setAttribute('data-lcw-motion', '');
    if (settings.focus) root.setAttribute('data-lcw-focus', '');
    if (!scene?.isConnected) {
      scene = document.createElement('div');
      scene.id = 'lcw-scenery';
      scene.setAttribute('aria-hidden', 'true');
      scene.inert = true;
      for (const name of ['moon', 'landscape', 'gate', 'particles', 'frame']) {
        const part = document.createElement('i'); part.className = `lcw-${name}`; scene.append(part);
      }
      document.body.append(scene);
      scheduleSurfaces();
    }
    const image = settings.theme === 'custom' && settings.customImage
      ? settings.customImage : chrome.runtime.getURL(`assets/${settings.theme === 'custom' ? 'sakura' : settings.theme}.png`);
    scene.style.backgroundImage = `url("${image}")`;
    for (const property of ['--lcw-accent','--lcw-surface']) root.style.removeProperty(property);
    if (settings.theme === 'custom') {
      root.style.setProperty('--lcw-accent', settings.accent);
      root.style.setProperty('--lcw-surface', settings.surface);
    }
  }
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !changes.worlds) return;
    revision++; settings = LCW.normalize(changes.worlds.newValue); loaded = true; apply();
  });
  const initialRevision = revision;
  chrome.storage.local.get('worlds').then(data => {
    if (revision !== initialRevision) return;
    settings = LCW.normalize(data.worlds); loaded = true; apply();
  }).catch(() => { /* Fail closed: leave the site untouched if storage is unavailable. */ });
  // Reveal wallpaper through large structural surfaces only. Never lift artwork above UI.
  function refreshSurfaces() {
    if (!loaded || !settings.enabled) return;
    document.querySelectorAll('[data-lcw-surface]').forEach(el => el.removeAttribute('data-lcw-surface'));
    const candidates = document.querySelectorAll('body, #__next, #app, main, div');
    for (const el of candidates) {
      if (el.id === 'lcw-scenery' || el.closest('[role="dialog"],[role="menu"],[role="listbox"],dialog,.monaco-editor,.cm-editor,.ace_editor')) continue;
      const box = el.getBoundingClientRect();
      if (box.width < innerWidth * .42 || box.height < innerHeight * .45) continue;
      const style = getComputedStyle(el);
      if (style.position === 'fixed' && el !== document.body) continue;
      if (style.backgroundImage !== 'none') continue;
      el.setAttribute('data-lcw-surface', '');
    }
  }
  let surfaceTimer;
  function scheduleSurfaces() {
    clearTimeout(surfaceTimer);
    surfaceTimer = setTimeout(refreshSurfaces, 150);
  }
  new MutationObserver(scheduleSurfaces).observe(document.body, {childList:true, subtree:true});
  addEventListener('resize', scheduleSurfaces);
  function checkRoute() {
    scheduleSurfaces();
    if (document.hidden) return;
    if (lastPath !== location.pathname || (loaded && settings.enabled && !scene?.isConnected)) {
      lastPath = location.pathname; apply();
    }
  }
  setInterval(checkRoute, 800);
  addEventListener('popstate', checkRoute);
  document.addEventListener('visibilitychange', checkRoute);
})();
