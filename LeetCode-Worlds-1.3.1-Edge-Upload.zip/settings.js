(() => {
  'use strict';
  const themes = ['sakura', 'cyber', 'samurai', 'study', 'custom'];
  const defaults = {theme: 'sakura', enabled: true, motion: false, focus: false};
  const normalize = (value = {}) => {
    value = value && typeof value === 'object' ? value : {};
    const color = (v, fallback) => /^#[0-9a-f]{6}$/i.test(v || '') ? v : fallback;
    return {accent: color(value.accent, '#d77a9d'), surface: color(value.surface, '#18181c'),
      customImage: typeof value.customImage === 'string' && value.customImage.length <= 2000000 && /^data:image\/jpeg;base64,[A-Za-z0-9+/=]+$/.test(value.customImage) ? value.customImage : '',
      theme: themes.includes(value.theme) ? value.theme : defaults.theme,
      ...Object.fromEntries(['enabled', 'motion', 'focus'].map(key =>
        [key, typeof value[key] === 'boolean' ? value[key] : defaults[key]]))};
  };
  globalThis.LCW = Object.freeze({themes, defaults, normalize});
})();
